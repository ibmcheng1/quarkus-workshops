export * from './fight.service';
import { FightService } from './fight.service';
export const APIS = [FightService];
